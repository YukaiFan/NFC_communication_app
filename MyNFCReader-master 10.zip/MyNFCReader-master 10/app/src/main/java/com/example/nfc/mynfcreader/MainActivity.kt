package com.example.nfc.mynfcreader

//import android.support.v8.app.AppCompatActivity

/*import android.app.Activity
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.NfcA
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Parcelable
import android.provider.Settings.ACTION_NFC_SETTINGS
import android.util.Log
import android.view.View
import android.widget.TextView
import android.widget.Toast
import com.example.nfc.mynfcreader.parser.NdefMessageParser
import com.example.nfc.mynfcreader.utils.Utils
import java.io.*
import java.nio.ByteBuffer
import java.util.jar.Manifest*/



import android.Manifest
import android.app.Activity
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.NfcA
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Parcelable
import android.provider.Settings.ACTION_NFC_SETTINGS
import android.util.Log
import android.view.View
import android.widget.*
import android.widget.AdapterView.OnItemClickListener
import com.example.nfc.mynfcreader.parser.NdefMessageParser
import com.example.nfc.mynfcreader.utils.Utils
import kotlinx.android.synthetic.main.activity_main.*
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.util.*
import kotlin.collections.ArrayList

//var float[][] values = new float[5][2]
//var bt1 = byteArrayOf(0xA1.toByte(), 0xA1.toByte(), 0xA1.toByte(), 0xA1.toByte())
//var bt2 = byteArrayOf(0xA1.toByte(), 0xA1.toByte(), 0xA1.toByte(), 0xA1.toByte())
var matrix = Array(10){Array(2) {"0"}}

private val dataList: ArrayList<String>? = ArrayList()
val pointList = java.util.ArrayList<Int>()
val pointList1 = java.util.ArrayList<Int>()
//val matrix1 = Array(10){"15"}


class MainActivity : Activity() {
    private var nfcAdapter: NfcAdapter? = null
    // launch our application when a new Tag or Card will be scanned
    private var pendingIntent: PendingIntent? = null
    // display the data read
   private var text: TextView? = null
    var adapter: ArrayAdapter<String>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //text = findViewById<view>(R.id.label) as TextView
        text = findViewById<View>(R.id.text) as TextView
        nfcAdapter = NfcAdapter.getDefaultAdapter(this)

        if (nfcAdapter == null) {
            Toast.makeText(this, "No NFC", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        pendingIntent = PendingIntent.getActivity(this, 0,
                Intent(this, this.javaClass)
                        .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0)


        if (dataList != null) {
            for (i in 0..9) {
                if(matrix[i][1].toFloat().toInt() == 15 ){
                    matrix[i][1] = 0.toString()
                    dataList.add( (9-i).toString() + ".   " + matrix[i][0] + "%  " + matrix[i][1] + "C")
                }else {
                    dataList.add((9 - i).toString() + ".   " + matrix[i][0] + "%  " + matrix[i][1] + "C")
                    //pointList1.add(45)
                }
            }

           /*
            dataList.add("9. 0% 0C")
            dataList.add("8. 0% 0C")
            dataList.add("7. 0% 0C")
            dataList.add("6. 0% 0C")
            dataList.add("5. 0% 0C")
            dataList.add("4. 0% 0C")
            dataList.add("3. 0% 0C")
            dataList.add("2. 0% 0C")
            dataList.add("1. 0% 0C")
            dataList.add("0. 0% 0C")
*/
        };
        adapter = ArrayAdapter(this,
                R.layout.listview_item, dataList)

        val listView:ListView = findViewById(R.id.Listview_1)

        listView.setAdapter(adapter)
        adapter!!.notifyDataSetChanged();

        listView.onItemClickListener = object : OnItemClickListener {

            override fun onItemClick(parent: AdapterView<*>, view: View,
                                     position: Int, id: Long) {

                // value of item that is clicked

                val itemValue = listView.getItemAtPosition(position)
                //text = findViewById<View>(R.id.label) as TextView
                // Toast the values
                Toast.makeText(applicationContext,
                        "Position :$position\nItem Value : $itemValue", Toast.LENGTH_LONG)
                        .show()
            }
        }

        val btn_click_me = findViewById(R.id.btn) as Button
        btn_click_me.setOnClickListener {
            // let the adapter know that data set has been changed
            // adapter will notify respective views and the views shall refresh
            if (Build.VERSION.SDK_INT >= 23) {
                val REQUEST_CODE_CONTACT = 101
                val permissions = arrayOf<String>(Manifest.permission.WRITE_EXTERNAL_STORAGE)

                for (str in permissions) {
                    if (checkSelfPermission(str) != PackageManager.PERMISSION_GRANTED) {

                        requestPermissions(permissions, REQUEST_CODE_CONTACT)
                    }
                }
            }
            val sdCardDir: String = Environment.getExternalStorageDirectory().getAbsolutePath()
            val saveFile = File(sdCardDir, "aaaa.txt") //new FileOutputStream(file, true);true：不覆盖写入文件

            var outStream: FileOutputStream? = null
            for (i in 0..9) {
                if (matrix[i][1].toFloat().toInt() == 15) {
                    matrix[i][1] = 0.toString()
                }
            }
            saveFile.printWriter().use { out ->

                out.println("0. "+ matrix[9][0]+"%   "+matrix[9][1]+"C  \n"
                        + "1. " + matrix[8][0]+"%   "+matrix[8][1]+"C  \n"
                        + "2. " + matrix[7][0]+"%   "+matrix[7][1]+"C  \n"
                        + "3. " + matrix[6][0]+"%   "+matrix[6][1]+"C  \n"
                        + "4. " + matrix[5][0]+"%   "+matrix[5][1]+"C  \n"
                        + "5. " + matrix[4][0]+"%   "+matrix[4][1]+"C  \n"
                        + "6. " + matrix[3][0]+"%   "+matrix[3][1]+"C  \n"
                        + "7. " + matrix[2][0]+"%   "+matrix[2][1]+"C  \n"
                        + "8. " + matrix[1][0]+"%   "+matrix[1][1]+"C  \n"
                        + "9. " + matrix[0][0]+"%   "+matrix[0][1]+"C  \n")
                //out.println(newMatirxvalue[0]+ "\n"+ newMatirxvalue[1]+ "\n"+ newMatirxvalue[2]+ "\n"+ newMatirxvalue[3]+ "\n" + newMatirxvalue[4]+ "\n")
                //out.println("Second line")
                Toast.makeText(this, "Save successfully", Toast.LENGTH_SHORT).show()
            }
        }



        for (i in 0..9) {

            pointList.add(matrix[i][0].toInt())
            //pointList.add(4)
        }

        for (i in 0..9) {
            if(matrix[i][1].toInt() == 0 ){
                matrix[i][1] = 15.toString()
                pointList1.add(matrix[i][1].toString().toFloat().toInt())

            }else {
                pointList1.add(matrix[i][1].toInt())
                //pointList1.add(45)
            }
        }

        chartView.maxY=100
        chartView.minY = 0
        chartView.maxY1=45
        chartView.minY1 = 15
        chartView.setChartPoints(pointList,pointList1)

/*
       val pointList2 = java.util.ArrayList<Int>()
        for (i in 0..9) {

            pointList2.add(3)
        }
        val pointList3 = java.util.ArrayList<Int>()
        for (i in 0..9) {

            pointList3.add(45)
        }
        if(chartView!=null){
            chartView.setChartPoints(pointList2,pointList3)
        }
        //chartView.setChartPoints(pointList2,pointList3)
*/
    }



    override fun onResume() {
        super.onResume()

        val nfcAdapterRefCopy = nfcAdapter
        if (nfcAdapterRefCopy != null) {
            if (!nfcAdapterRefCopy.isEnabled())
                showNFCSettings()

            nfcAdapterRefCopy.enableForegroundDispatch(this, pendingIntent, null, null)
        }
    }

    override fun onNewIntent(intent: Intent) {
        setIntent(intent)
        resolveIntent(intent)
    }


    private fun showNFCSettings() {
        Toast.makeText(this, "You need to enable NFC", Toast.LENGTH_SHORT).show()
        val intent = Intent(ACTION_NFC_SETTINGS)
        startActivity(intent)
    }

    /**
     * Tag data is converted to string to display
     *
     * @return the data dumped from this tag in String format
     */
    private fun dumpTagData(tag: Tag): String {
        val sb = StringBuilder()
        val id = tag.getId()
        //sb.append("ID (hex): ").append(Utils.toHex(id)).append('\n')
        //sb.append("Serial number (hex): ").append(Utils.toReversedHex(id)).append('\n')

        //sb.append("ID (dec): ").append(Utils.toReversedDec(id)).append('\n')
        val tagFromIntent: Tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG)
        val nfcA = NfcA.get(tag)
        nfcA.connect()

        //for(x in 0..4){
            val SELECT = byteArrayOf(0x30.toByte(),0x04.toByte()) //0x30 read cmd, 4h number of negative PWD_AUTH commands limit reached。
            val result = nfcA.transceive(SELECT)
            val bt3 = byteArrayOf(0xA1.toByte(), 0xA1.toByte(), 0xA1.toByte(), 0xA1.toByte())
            val bt4 = byteArrayOf(0xA1.toByte(), 0xA1.toByte(), 0xA1.toByte(), 0xA1.toByte())

            for (x in 0 until 4){
                bt3.set(x, result.get(7-x))
            }
            for (x in 0 until 4){
                bt4.set(x, result.get(3-x))
            }

            //sb.append("Memory (HEX): ").append(Utils.toReversedHex(result)).append('\n')
            //sb.append("Humidity (HEX): ").append(Utils.toHex(bt4)).append('\n')
            //sb.append("Temperature (HEX): ").append(Utils.toHex(bt3)).append('\n')
            sb.append("Humidity (DEC): ").append(ByteBuffer.wrap(bt4).getFloat()).append("%",'\n')
            sb.append("Temperature (DEC): ").append(ByteBuffer.wrap(bt3).getFloat()).append("C",'\n')

            matrix[9][0]= matrix[8][0]
            matrix[8][0]= matrix[7][0]
            matrix[7][0]= matrix[6][0]
            matrix[6][0]= matrix[5][0]
            matrix[5][0]= matrix[4][0]
            matrix[4][0]= matrix[3][0]
            matrix[3][0]= matrix[2][0]
            matrix[2][0]= matrix[1][0]
            matrix[1][0]= matrix[0][0]
            matrix[0][0]= ByteBuffer.wrap(bt4).getFloat().toString()

            matrix[9][1]= matrix[8][1]
            matrix[8][1]= matrix[7][1]
            matrix[7][1]= matrix[6][1]
            matrix[6][1]= matrix[5][1]
            matrix[5][1]= matrix[4][1]
            matrix[4][1]= matrix[3][1]
            matrix[3][1]= matrix[2][1]
            matrix[2][1]= matrix[1][1]
            matrix[1][1]= matrix[0][1]
            matrix[0][1]= ByteBuffer.wrap(bt3).getFloat().toString()
      

        if (dataList != null) {
            dataList.clear()
            for (i in 0..9) {
                if (matrix[i][1].toFloat().toInt() == 15) {
                    matrix[i][1] = 0.toString()
                    dataList.add((9 - i).toString() + ".   " + matrix[i][0] + "%  " + matrix[i][1] + "C")
                } else {
                    dataList.add((9 - i).toString() + ".   " + matrix[i][0] + "%  " + matrix[i][1] + "C")
                    //pointList1.add(45)

                }
            }
            /*dataList.add( "9. "+ matrix[0][0] + "%  " + matrix[0][1] + "C")
            dataList.add( "8. "+ matrix[1][0] + "%  " + matrix[1][1] + "C")
            dataList.add( "7. "+ matrix[2][0] + "%  " + matrix[2][1] + "C")
            dataList.add( "6. "+ matrix[3][0] + "%  " + matrix[3][1] + "C")
            dataList.add( "5. "+ matrix[4][0] + "%  " + matrix[4][1] + "C")
            dataList.add( "4. "+ matrix[5][0] + "%  " + matrix[5][1] + "C")
            dataList.add( "3. "+ matrix[6][0] + "%  " + matrix[6][1] + "C")
            dataList.add( "2. "+ matrix[7][0] + "%  " + matrix[7][1] + "C")
            dataList.add( "1. "+ matrix[8][0] + "%  " + matrix[8][1] + "C")
            dataList.add( "0. "+ matrix[9][0] + "%  " + matrix[9][1] + "C")
*/
            adapter?.notifyDataSetChanged()
        };




        //humidity
        pointList.clear()
        pointList.add(matrix[9][0].toFloat().toInt())
        //pointList.add(matrix[0][0].toInt())
        pointList.add(matrix[8][0].toFloat().toInt())
        pointList.add(matrix[7][0].toFloat().toInt())
        pointList.add(matrix[6][0].toFloat().toInt())
        pointList.add(matrix[5][0].toFloat().toInt())
        pointList.add(matrix[4][0].toFloat().toInt())
        pointList.add(matrix[3][0].toFloat().toInt())
        pointList.add(matrix[2][0].toFloat().toInt())
        pointList.add(matrix[1][0].toFloat().toInt())
        pointList.add(matrix[0][0].toFloat().toInt())
        //temperature
        pointList1.clear()
       /* pointList1.add(matrix[9][1].toFloat().toInt())
        pointList1.add(matrix[8][1].toFloat().toInt())
        pointList1.add(matrix[7][1].toFloat().toInt())
        pointList1.add(matrix[6][1].toFloat().toInt())
        pointList1.add(matrix[5][1].toFloat().toInt())
        pointList1.add(matrix[4][1].toFloat().toInt())
        pointList1.add(matrix[3][1].toFloat().toInt())
        pointList1.add(matrix[2][1].toFloat().toInt())
        pointList1.add(matrix[1][1].toFloat().toInt())
        pointList1.add(matrix[0][1].toFloat().toInt())
*/

        for (i in 0..9) {
            if(matrix[9-i][1].toFloat().toInt() == 0 ){
                matrix[9-i][1] = 15.toString()
                pointList1.add(matrix[9-i][1].toString().toFloat().toInt())
            }else {
                pointList1.add(matrix[9 - i][1].toFloat().toInt())
                //pointList1.add(45)
            }
        }


        if(chartView!=null){
            //chartView.maxY=100
            //chartView.maxY1=45
            chartView.setChartPoints(pointList, pointList1)
        }



        return sb.toString()
    }



    private fun resolveIntent(intent: Intent) {
        val action = intent.action

        if (NfcAdapter.ACTION_TAG_DISCOVERED == action
                || NfcAdapter.ACTION_TECH_DISCOVERED == action
                || NfcAdapter.ACTION_NDEF_DISCOVERED == action) {
            val rawMsgs = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES)

            if (rawMsgs != null) {
                Log.i("NFC", "Size:" + rawMsgs.size);
                val ndefMessages: Array<NdefMessage> = Array(rawMsgs.size, {i -> rawMsgs[i] as NdefMessage});
                displayNfcMessages(ndefMessages)
            } else {
                val empty = ByteArray(0)
                val id = intent.getByteArrayExtra(NfcAdapter.EXTRA_ID)
                val tag = intent.getParcelableExtra<Parcelable>(NfcAdapter.EXTRA_TAG) as Tag
                val payload = dumpTagData(tag).toByteArray()
                val record = NdefRecord(NdefRecord.TNF_UNKNOWN, empty, id, payload)
                val emptyMsg = NdefMessage(arrayOf(record))
                val emptyNdefMessages: Array<NdefMessage> = arrayOf(emptyMsg);
                displayNfcMessages(emptyNdefMessages)
            }
        }
    }


    private fun displayNfcMessages(msgs: Array<NdefMessage>?) {
        if (msgs == null || msgs.isEmpty())
            return

        val builder = StringBuilder()
        val records = NdefMessageParser.parse(msgs[0])
        val size = records.size

        for (i in 0 until size) {
            val record = records[i]
            val str = record.str()
            builder.append(str).append("\n")
        }

        text?.setText(builder.toString())

    }
}
